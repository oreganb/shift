---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Actor
---

# Actor

## Overview
Any party participating in flexibility or transactive-energy activity: consumers, prosumers, operators, aggregators, communities and authorities.

**OWL identifier:** `shift:Actor`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `actorID` | `string` |
| `actorType` | `string` |
| `certificationLevel` | `string` |
| `country` | `string` |
| `isActive` | `boolean` |
| `marketRole` | `string` |
| `participationEndDate` | `date` |
| `participationStartDate` | `date` |
| `region` | `string` |
| `registrationNumber` | `string` |
| `status` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `participatesIn` | [[Market Operator]] |
| [[Flexibility Schedule]] `belongsToActor` | this |
| [[Flexibility Contract]] `contractBetween` | this |
| [[Tariff Plan]] `definedBy` | this |
| [[PeerFlex Clearing Mechanism]] `designedByActor` | this |
| BehindTheMeterFlexService `executedByUser` | this |
| Node `governedByDSO` | this |
| EnergyCommunity `hasMember` | this |
| [[Peer Trading]] `initiatedBy` | this |
| [[Transactive Platform]] `integratesActor` | this |
| RegulatoryAuthority `licensesActor` | this |
| [[Control Asset]] `managedByActor` | this |
| [[Smart Meter Asset]] `monitorsActor` | this |
| [[Market Bidding]] `offeredBy` | this |
| [[Transactive Platform]] `operatedByActor` | this |
| [[Market Operator]] `operatesMarket` | this |
| [[Sensor Asset]] `ownedBy` | this |
| [[Flexibility Trade]] `tradeBuyer` | this |
| [[Flexibility Trade]] `tradeSeller` | this |

## Reasoning Rules
SHIFT-RR-00, SHIFT-RR-01, SHIFT-RR-03, SHIFT-RR-15, SHIFT-RR-20, SHIFT-RR-26, SHIFT-RR-30 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:closeMatch | [[SEAS Actor]] | Both: an entity that can perform actions in the energy system. |
| skos:relatedMatch | [[SEAS Role]] | SHIFT encodes role as a literal (marketRole DP); SEAS reifies Role as a class an entity can hold per context. SEAS's pattern is richer for multi-role actors; SHIFT's is cheaper to query. |
| skos:relatedMatch | [[OADR VEN]] | A VEN is the protocol endpoint a participating actor operates. |
| skos:closeMatch | [[CIM MarketParticipant]] | IEC 62325 MarketParticipant is the direct counterpart of a SHIFT market actor. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]