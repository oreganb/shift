# Participants

## Included Concepts
- [[Actor]]
- [[Consumer]]
- [[Flexumer]]
- [[Prosumer]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]