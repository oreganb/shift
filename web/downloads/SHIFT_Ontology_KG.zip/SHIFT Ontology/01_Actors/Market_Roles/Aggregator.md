---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Aggregator
---

# Aggregator

## Overview
An actor that pools flexibility from multiple assets or actors and offers it to markets or system operators as a single portfolio.

**OWL identifier:** `shift:Aggregator`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Semantic Relationships

| Relationship | Target |
|---|---|
| `aggregates` | FlexibilityServiceProvider |

## Reasoning Rules
SHIFT-RR-14, SHIFT-RR-28, SHIFT-RR-34 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[OADR VTN]] | A VTN is the protocol top node an aggregator or utility operates; it is an endpoint, not the market actor itself. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]