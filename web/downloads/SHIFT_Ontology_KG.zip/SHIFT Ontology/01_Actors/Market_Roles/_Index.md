# Market Roles

## Included Concepts
- [[Aggregator]]
- [[DSO]]
- [[Market Operator]]
- [[TSO]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]