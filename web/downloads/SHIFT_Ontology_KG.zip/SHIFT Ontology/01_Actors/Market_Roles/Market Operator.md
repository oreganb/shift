---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Market Operator
---

# Market Operator

## Overview
An actor operating a trading venue: clearing, matching and settlement of energy or flexibility products.

**OWL identifier:** `shift:MarketOperator`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Semantic Relationships

| Relationship | Target |
|---|---|
| `operatesMarket` | [[Actor]] |
| [[Flexibility Trade]] `clearedBy` | this |
| ReserveCapacityService `clearedInMarket` | this |
| [[Flexibility Contract]] `enforcedBy` | this |
| [[Demand Response]] `managedBy` | this |
| [[Actor]] `participatesIn` | this |
| [[Flexibility Service]] `participatesInMarket` | this |
| [[Market Bidding]] `settledBy` | this |
| [[Demand Response]] `triggeredBy` | this |

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:broadMatch | [[SEAS Operator]] | As for DSO: seas:Operator generalises. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]