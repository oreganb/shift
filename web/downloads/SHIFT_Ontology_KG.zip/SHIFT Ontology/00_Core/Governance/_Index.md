# Governance

## Included Concepts
- [[Design Principles]]
- [[Naming Conventions]]
- [[Reasoning Rules]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]