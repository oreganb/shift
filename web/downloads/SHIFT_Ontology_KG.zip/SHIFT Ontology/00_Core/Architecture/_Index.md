# Architecture

## Included Concepts
- [[Ontology Architecture]]
- [[SHIFT Ontology]]
- [[Semantic Relationships]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]