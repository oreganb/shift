# Research Platforms

## Included Concepts
- [[FLEXUS]]
- [[INNOV8HEAT]]
- [[O-CEI]]
- [[OPTIX]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]