---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Flexibility Contract
---

# Flexibility Contract

## Overview
A formal agreement governing service delivery: obligations, windows, prices, penalties.

**OWL identifier:** `shift:FlexibilityContract`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `activationNoticePeriod_min` | `integer` |
| `contractEndTime` | `dateTime` |
| `contractID` | `string` |
| `contractStartTime` | `dateTime` |
| `contractStatus` | `string` |
| `contractType` | `string` |
| `incentiveBonus_EURperkWh` | `float` |
| `isAutoRenewable` | `boolean` |
| `isSmartContract` | `boolean` |
| `minimumDeliveryVolume_kWh` | `float` |
| `penaltyRate_EURperkWh` | `float` |
| `pricePerUnit_EURperkWh` | `float` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `contractBetween` | [[Actor]] |
| `definesSchedule` | [[Flexibility Schedule]] |
| `enforcedBy` | [[Market Operator]] |
| `governsService` | [[Flexibility Service]] |
| `monitoredBy` | [[Sensor Asset]] |
| `usesTariffPlan` | [[Tariff Plan]] |
| `validatedBy` | FlexibilityServiceProvider |
| [[Demand Response]] `definedInContract` | this |
| BehindTheMeterFlexService `definedInLocalPolicy` | this |
| [[Flexibility Trade]] `relatedContract` | this |
| [[Tariff Plan]] `usedInContract` | this |

## Reasoning Rules
SHIFT-RR-12, SHIFT-RR-26 — see [[Reasoning Rules]]

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]