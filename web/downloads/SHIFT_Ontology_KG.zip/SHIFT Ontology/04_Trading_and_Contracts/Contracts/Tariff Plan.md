---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Tariff Plan
---

# Tariff Plan

## Overview
A pricing structure applicable to an actor: rates, caps, validity, dynamism.

**OWL identifier:** `shift:TariffPlan`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `applicableToUserType` | `string` |
| `applicableVoltageLevel` | `string` |
| `baseRate_EURperkWh` | `float` |
| `billingFrequency` | `string` |
| `criticalPeakRate_EURperkWh` | `float` |
| `incentiveBonus_EURperkWh` | `float` |
| `isDynamic` | `boolean` |
| `isUserSelectable` | `boolean` |
| `lastUpdatedAt` | `dateTime` |
| `offPeakRate_EURperkWh` | `float` |
| `peakRate_EURperkWh` | `float` |
| `penaltyRate_EURperkWh` | `float` |
| `tariffID` | `string` |
| `tariffType` | `string` |
| `validFrom` | `dateTime` |
| `validUntil` | `dateTime` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `definedBy` | [[Actor]] |
| `drivesBTMFlexService` | BehindTheMeterFlexService |
| `linkedToFlexService` | [[Flexibility Service]] |
| `referencedInForecast` | [[Forecast Data]] |
| `usedInContract` | [[Flexibility Contract]] |
| [[Transactive Platform]] `hostsTariffPlan` | this |
| [[PeerFlex Clearing Mechanism]] `influencesTariffPlan` | this |
| [[Flexibility Contract]] `usesTariffPlan` | this |
| BehindTheMeterFlexService `usesTariffSignal` | this |

## Reasoning Rules
SHIFT-RR-03, SHIFT-RR-15, SHIFT-RR-23, SHIFT-RR-31 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[CIM Tariff]] | IEC 61968 Customers Tariff overlaps SHIFT TariffPlan; SHIFT adds dynamic/cap/conflict attributes used by RR-15/20/23/31. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]