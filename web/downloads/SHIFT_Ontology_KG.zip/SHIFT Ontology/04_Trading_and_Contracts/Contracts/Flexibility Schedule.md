---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Flexibility Schedule
---

# Flexibility Schedule

## Overview
A time-bounded plan of available and committed power for a service or asset.

**OWL identifier:** `shift:FlexibilitySchedule`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `availablePower_kW` | `float` |
| `committedPower_kW` | `float` |
| `confidenceScore` | `decimal` |
| `createdBySystem` | `boolean` |
| `duration_min` | `integer` |
| `endTime` | `dateTime` |
| `isDispatchable` | `boolean` |
| `isInterruptible` | `boolean` |
| `isValid` | `boolean` |
| `scheduleID` | `string` |
| `scheduleType` | `string` |
| `startTime` | `dateTime` |
| `updatedAt` | `dateTime` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `associatedWithAsset` | [[Asset]] |
| `associatedWithService` | [[Flexibility Service]] |
| `belongsToActor` | [[Actor]] |
| `confirmsTrade` | [[Flexibility Trade]] |
| `definedInContract` | [[Flexibility Contract]] |
| `linkedToForecast` | [[Forecast Data]] |
| `scheduledBy` | FlexibilityServiceProvider |
| `updatedBy` | [[Control Asset]] |
| `validatedBy` | FlexibilityServiceProvider |
| [[Flexibility Contract]] `definesSchedule` | this |
| [[Demand Response]] `linkedToSchedule` | this |
| [[Flexibility Trade]] `relatedSchedule` | this |
| [[Control Asset]] `updatesSchedule` | this |
| [[Smart Meter Asset]] `usedForValidation` | this |
| [[Forecast Data]] `usedInSchedule` | this |

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[SEAS PlanningActivity]] | Same data-vs-activity duality as ForecastData. |
| skos:relatedMatch | [[OADR Schedule]] | Both are time plans; OpenADR's is signal-delivery oriented. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]