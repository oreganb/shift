# Contracts

## Included Concepts
- [[Flexibility Contract]]
- [[Flexibility Schedule]]
- [[Tariff Plan]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]