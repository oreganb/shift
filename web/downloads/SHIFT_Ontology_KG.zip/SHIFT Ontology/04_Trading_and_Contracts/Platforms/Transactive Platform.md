---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Transactive Platform
---

# Transactive Platform

## Overview
The middleware operating the market loop (FLEXUS): matching, pricing, governance, compliance.

**OWL identifier:** `shift:TransactivePlatform`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `complianceStatus` | `string` |
| `governanceModel` | `string` |
| `interoperabilityLevel` | `string` |
| `isClearingEngineDistributed` | `boolean` |
| `isPermissioned` | `boolean` |
| `lastUpdatedAt` | `dateTime` |
| `marketType` | `string` |
| `platformID` | `string` |
| `platformName` | `string` |
| `platformRegion` | `string` |
| `supportsAutomatedMatching` | `boolean` |
| `supportsRealTimePricing` | `boolean` |
| `supportsSmartContracts` | `boolean` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `clearsTrade` | [[Flexibility Trade]] |
| `controlsViaAsset` | [[Control Asset]] |
| `hostsTariffPlan` | [[Tariff Plan]] |
| `includesClearingMechanism` | [[PeerFlex Clearing Mechanism]] |
| `integratesActor` | [[Actor]] |
| `interactsWithNode` | Node |
| `operatedByActor` | [[Actor]] |
| `receivesDataFromMeter` | [[Smart Meter Asset]] |
| [[PeerFlex Clearing Mechanism]] `deployedOnPlatform` | this |
| [[Peer Trading]] `executedThroughPlatform` | this |
| [[Smart Meter Asset]] `feedsIntoPlatform` | this |
| [[Control Asset]] `reportsToPlatform` | this |

## Reasoning Rules
SHIFT-RR-03 — see [[Reasoning Rules]]

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]