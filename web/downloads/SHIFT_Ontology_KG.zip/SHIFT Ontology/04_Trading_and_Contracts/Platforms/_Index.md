# Platforms

## Included Concepts
- [[Transactive Platform]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]