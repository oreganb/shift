---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Flexibility Trade
---

# Flexibility Trade

## Overview
One executed or executing flexibility commitment: parties, volume, price, window, status.

**OWL identifier:** `shift:FlexibilityTrade`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `createdByAutomation` | `boolean` |
| `energyVolume_kWh` | `float` |
| `failureReason` | `string` |
| `isDispatchable` | `boolean` |
| `isValidated` | `boolean` |
| `price_EURperkWh` | `float` |
| `priorityLevel` | `integer` |
| `settlementStatus` | `string` |
| `tradeEndTime` | `dateTime` |
| `tradeID` | `string` |
| `tradeStartTime` | `dateTime` |
| `tradeTimestamp` | `dateTime` |
| `tradeType` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `clearedBy` | [[Market Operator]] |
| `dispatchedBy` | FlexibilityServiceProvider |
| `governsService` | [[Flexibility Service]] |
| `relatedContract` | [[Flexibility Contract]] |
| `relatedSchedule` | [[Flexibility Schedule]] |
| `targetedLocation` | Node |
| `tradeBuyer` | [[Actor]] |
| `tradeSeller` | [[Actor]] |
| `validatedBy` | FlexibilityServiceProvider |
| [[Transactive Platform]] `clearsTrade` | this |
| [[Flexibility Schedule]] `confirmsTrade` | this |
| [[PeerFlex Clearing Mechanism]] `governsTrade` | this |
| [[Trade Window]] `includesTrade` | this |
| Node `usedByFlexTrade` | this |

## Reasoning Rules
SHIFT-RR-01, SHIFT-RR-04, SHIFT-RR-06, SHIFT-RR-07, SHIFT-RR-08, SHIFT-RR-15, SHIFT-RR-16, SHIFT-RR-22, SHIFT-RR-25, SHIFT-RR-27, SHIFT-RR-30 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[CIM EnergyTransaction]] | CIM's transaction model is wholesale-oriented; SHIFT's trade model adds P2P/community semantics CIM lacks. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]