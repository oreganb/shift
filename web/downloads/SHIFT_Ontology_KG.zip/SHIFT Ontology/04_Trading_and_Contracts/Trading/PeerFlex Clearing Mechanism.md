---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - PeerFlex Clearing Mechanism
---

# PeerFlex Clearing Mechanism

## Overview
The algorithmic clearing arrangement for peer flexibility: type, frequency, transparency, audit.

**OWL identifier:** `shift:PeerFlexClearingMechanism`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `algorithmVersion` | `string` |
| `clearingFrequency_min` | `integer` |
| `clearingMechanismID` | `string` |
| `clearingType` | `string` |
| `codeURL` | `anyURI` |
| `includesEquityWeighting` | `boolean` |
| `isDecentralizedExecution` | `boolean` |
| `isRegulatorApproved` | `boolean` |
| `isTransparentLogic` | `boolean` |
| `lastAuditDate` | `dateTime` |
| `usesSmartContracts` | `boolean` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `deployedOnPlatform` | [[Transactive Platform]] |
| `designedByActor` | [[Actor]] |
| `governsTrade` | [[Flexibility Trade]] |
| `influencesTariffPlan` | [[Tariff Plan]] |
| `linkedToNode` | Node |
| [[Flexibility Trade]] `clearedBy` | this |
| [[Transactive Platform]] `includesClearingMechanism` | this |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]