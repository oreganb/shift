# Trading

## Included Concepts
- [[Flexibility Trade]]
- [[PeerFlex Clearing Mechanism]]
- [[Trade Window]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]