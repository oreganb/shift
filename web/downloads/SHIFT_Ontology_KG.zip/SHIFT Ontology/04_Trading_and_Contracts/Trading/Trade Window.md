---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Trade Window
---

# Trade Window

## Overview
A discrete market interval (30 min in FLEXUS) within which trades clear and rules are evaluated.

**OWL identifier:** `shift:TradeWindow`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `clearingPrice_EURperkWh` | `float` |
| `duration_min` | `integer` |
| `endTime` | `dateTime` |
| `energyCommitted_kWh` | `float` |
| `isMarketClearingWindow` | `boolean` |
| `isRollingWindow` | `boolean` |
| `isValidationRequired` | `boolean` |
| `lastUpdatedAt` | `dateTime` |
| `priorityScore` | `decimal` |
| `startTime` | `dateTime` |
| `windowID` | `string` |
| `windowType` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `controlsAssetOperation` | [[Control Asset]] |
| `includesTrade` | [[Flexibility Trade]] |
| `informedByForecast` | [[Forecast Data]] |
| `managedBy` | FlexibilityServiceProvider |
| `operatesOnNode` | Node |
| `usedByService` | [[Flexibility Service]] |
| [[Control Asset]] `assignedToWindow` | this |
| Node `includedInTradeWindow` | this |
| [[Forecast Data]] `usedInTradeWindow` | this |

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[OADR Interval]] | OpenADR Interval is the signal-timing primitive; TradeWindow is the market-clearing primitive. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]