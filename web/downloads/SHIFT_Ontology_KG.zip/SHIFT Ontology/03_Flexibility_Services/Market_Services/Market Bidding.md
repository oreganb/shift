---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Market Bidding
---

# Market Bidding

## Overview
Flexibility offered into an organised market; carries offered/cleared volume and pricing mode.

**OWL identifier:** `shift:MarketFlexibilityService`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `clearedVolume_kWh` | `float` |
| `dispatchPriorityLevel` | `integer` |
| `isBilateralContractAllowed` | `boolean` |
| `isLocationConstrained` | `boolean` |
| `isPayAsBid` | `boolean` |
| `isValidated` | `boolean` |
| `lastMarketParticipationTime` | `dateTime` |
| `marketFlexType` | `string` |
| `offeredVolume_kWh` | `float` |
| `price_EURperkWh` | `float` |
| `serviceID` | `string` |
| `settlementStatus` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `clearedBy` | [[Market Operator]] |
| `definedInContract` | [[Flexibility Contract]] |
| `linkedToSchedule` | [[Flexibility Schedule]] |
| `measuredBy` | [[Smart Meter Asset]] |
| `offeredBy` | [[Actor]] |
| `settledBy` | [[Market Operator]] |
| `targetedAtZone` | Node |
| `tradedAs` | FlexibilityProduct |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]