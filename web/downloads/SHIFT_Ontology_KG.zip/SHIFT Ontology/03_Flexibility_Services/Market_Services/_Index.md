# Market Services

## Included Concepts
- [[Market Bidding]]
- [[Peer Trading]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]