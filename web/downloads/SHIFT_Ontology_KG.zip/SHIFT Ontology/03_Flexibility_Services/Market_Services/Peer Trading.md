---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Peer Trading
---

# Peer Trading

## Overview
Flexibility exchanged directly between peers, optionally off-market; carries matching algorithm and consent status.

**OWL identifier:** `shift:PeerToPeerFlexibilityService`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `agreedFlexVolume_kWh` | `float` |
| `agreedPrice_EURperkWh` | `float` |
| `consentStatus` | `string` |
| `isCommunityModerated` | `boolean` |
| `isExecutedOffMarket` | `boolean` |
| `isSmartContractBased` | `boolean` |
| `optInWindow_min` | `integer` |
| `peerFlexType` | `string` |
| `peerMatchingAlgorithm` | `string` |
| `serviceID` | `string` |
| `transactionHash` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `clearedBy` | [[Market Operator]] |
| `definedInContract` | [[Flexibility Contract]] |
| `executedThroughPlatform` | [[Transactive Platform]] |
| `initiatedBy` | [[Actor]] |
| `linkedToSchedule` | [[Flexibility Schedule]] |
| `offeredBy` | [[Actor]] |
| `verifiedBy` | [[Sensor Asset]] |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]