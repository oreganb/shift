---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Demand Response
---

# Demand Response

## Overview
Load modification in response to signals or events; carries curtailment bounds, notification time and baseline method.

**OWL identifier:** `shift:DemandResponseService`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `baselineMethod` | `string` |
| `comfortImpactScore` | `decimal` |
| `customerOptOutAvailable` | `boolean` |
| `drType` | `string` |
| `eventNotificationTime_min` | `integer` |
| `incentiveRate_EURperkWh` | `float` |
| `isAutomated` | `boolean` |
| `isInterruptible` | `boolean` |
| `maximumCurtailment_kW` | `float` |
| `minimumCurtailment_kW` | `float` |
| `responseTime_sec` | `integer` |
| `scheduledActivation` | `boolean` |
| `serviceID` | `string` |
| `verificationMethod` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `definedInContract` | [[Flexibility Contract]] |
| `deliveredBy` | [[Asset]] |
| `linkedToSchedule` | [[Flexibility Schedule]] |
| `managedBy` | FlexibilityServiceProvider |
| `triggeredBy` | [[DSO]] |
| `verifiedBy` | [[Sensor Asset]] |

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[OADR Event]] | An OpenADR Event requests load shed; a SHIFT DemandResponseService is the contracted capability that answers it. Request vs capability. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]