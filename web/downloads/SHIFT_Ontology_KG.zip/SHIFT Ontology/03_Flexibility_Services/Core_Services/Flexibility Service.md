---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Flexibility Service
---

# Flexibility Service

## Overview
A grid- or market-facing service delivered by modulating consumption, generation or storage. NOTE: not the same sense as saref:Service, which is a device function exposed to a network.

**OWL identifier:** `shift:FlexibilityService`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `activationTime_sec` | `integer` |
| `baselineMethod` | `string` |
| `comfortImpactScore` | `decimal` |
| `isAutomated` | `boolean` |
| `maximumDuration_min` | `integer` |
| `minimumDuration_min` | `integer` |
| `responseAccuracy_percent` | `decimal` |
| `serviceID` | `string` |
| `verificationMethod` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `definedInContract` | [[Flexibility Contract]] |
| `deliveredBy` | [[Asset]] |
| `linkedToSchedule` | [[Flexibility Schedule]] |
| `managedBy` | FlexibilityServiceProvider |
| `participatesInMarket` | [[Market Operator]] |
| `verifiedBy` | [[Sensor Asset]] |
| [[Control Asset]] `activatesService` | this |
| [[Flexibility Schedule]] `associatedWithService` | this |
| [[Flexibility Contract]] `governsService` | this |
| [[Tariff Plan]] `linkedToFlexService` | this |
| [[Asset]] `participatesInFlexibility` | this |
| [[Trade Window]] `usedByService` | this |
| [[Sensor Asset]] `usedInFlexService` | this |
| [[Asset]] `usedInFlexibilityService` | this |
| [[Forecast Data]] `usedInService` | this |

## Reasoning Rules
SHIFT-RR-05, SHIFT-RR-09, SHIFT-RR-11, SHIFT-RR-12, SHIFT-RR-13, SHIFT-RR-17, SHIFT-RR-19, SHIFT-RR-25, SHIFT-RR-34 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[SAREF Service]] | FALSE FRIEND. saref:Service is a device function exposed to a network; shift:FlexibilityService is a grid/market service. The name collision is exactly why alignment must be explicit. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]