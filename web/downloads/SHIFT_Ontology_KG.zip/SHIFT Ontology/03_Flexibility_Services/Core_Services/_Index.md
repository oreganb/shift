# Core Services

## Included Concepts
- [[Curtailment]]
- [[Demand Response]]
- [[Flexibility Service]]
- [[Load Shifting]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]