# Grid Services

## Included Concepts
- [[Congestion Management]]
- [[Frequency Regulation]]
- [[Voltage Control]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]