---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Frequency Regulation
---

# Frequency Regulation

## Overview
Fast active-power response to frequency deviation; carries thresholds, prequalification and settlement interval.

**OWL identifier:** `shift:FrequencyRegulationService`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `activationSignalType` | `string` |
| `dispatchAccuracy_percent` | `decimal` |
| `frequencyDeviationThreshold_Hz` | `decimal` |
| `frequencyResponseType` | `string` |
| `isBidirectional` | `boolean` |
| `isPrequalified` | `boolean` |
| `lastResponseTimestamp` | `dateTime` |
| `reliabilityScore` | `decimal` |
| `reservePowerAvailable_kW` | `float` |
| `responseTime_ms` | `integer` |
| `serviceID` | `string` |
| `settlementInterval_min` | `integer` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `definedInContract` | [[Flexibility Contract]] |
| `deliveredBy` | [[Asset]] |
| `linkedToSchedule` | [[Flexibility Schedule]] |
| `managedBy` | FlexibilityServiceProvider |
| `triggeredBy` | [[DSO]] |
| `usedForGridStabilization` | GridService |
| `validatedBy` | FlexibilityServiceProvider |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]