---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Voltage Control
---

# Voltage Control

## Overview
Reactive or active power support for voltage regulation; carries kVAR capacity and threshold range.

**OWL identifier:** `shift:VoltageSupportService`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `activationResponseTime_ms` | `integer` |
| `equipmentType` | `string` |
| `isBidirectionalReactiveSupport` | `boolean` |
| `isContinuousResponse` | `boolean` |
| `powerFactorRange` | `string` |
| `reactivePowerCapacity_kVAR` | `float` |
| `regulationAccuracy_percent` | `decimal` |
| `serviceID` | `string` |
| `voltageSupportType` | `string` |
| `voltageThresholdRange_V` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `definedInContract` | [[Flexibility Contract]] |
| `deliveredBy` | [[Asset]] |
| `linkedToSchedule` | [[Flexibility Schedule]] |
| `managedBy` | FlexibilityServiceProvider |
| `triggeredBy` | [[DSO]] |
| `validatedBy` | FlexibilityServiceProvider |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]