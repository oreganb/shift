---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Semantic Interoperability
---

# Semantic Interoperability

## Overview
Shared meaning across systems, achieved through explicit alignment (see the SKOS mapping tables under 08_Standards), never through name coincidence. The cautionary example inside this vault: saref:Service (a device function exposed to a network) versus shift:FlexibilityService (a grid/market service) — same word, disjoint concepts.

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]

## Semantic Relationships

| Relationship | Target |
|---|---|
| partOf | [[SHIFT Ontology]] |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Knowledge Graph Engineering]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
