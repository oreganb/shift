# Semantic Engineering

## Included Concepts
- [[Knowledge Graph Engineering]]
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Semantic Modelling]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]