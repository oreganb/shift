# AI and Analytics

## Included Concepts
- [[Explainable AI]]
- [[Machine Learning Integration]]
- [[Semantic Feature Engineering]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]