# SHIFT Ontology

## Core Domains
- [[Actor]]
- [[Asset]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]
- [[Reasoning Rule]]

## Main Folders
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Contract]]
- [[Semantic Validation]]
- [[Transactive Platform]]

## Standards
- [[OWL2]]
- [[SEAS]]
- [[OpenADR]]
- [[SGAM Placement]]
- [[RDF]]
- [[SAREF]]
- [[CIM]]
- [[OpenADR]]

## Methodologies
- [[Ontology Engineering]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]
- [[Explainable AI]]

## Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]