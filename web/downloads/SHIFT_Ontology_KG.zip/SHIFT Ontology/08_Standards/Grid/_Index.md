# Grid

## Included Concepts
- [[CIM]]
- [[IEC 61850]]
- [[IEC 61970]]
- [[IEEE 2030.5]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]