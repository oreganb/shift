---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - standard
aliases:
  - CIM
---

# CIM

## Overview
IEC Common Information Model (61970 grid / 61968 distribution / 62325 market), published as RDF by TNO. Thousands of classes; only the ten SHIFT aligns to are catalogued in the CIM folder. IRIs are UNVERIFIED against the TNO release (portal is JS-rendered) — verify before asserting in any TTL. CIM owns electrical topology depth; SHIFT references it and adds OWL 2 reasoning plus P2P/community constructs CIM lacks.

## SHIFT Alignment (SKOS — complement, not replacement)

| SHIFT | relation | external | rationale |
|---|---|---|---|
| [[Actor]] | skos:closeMatch | [[CIM MarketParticipant]] | IEC 62325 MarketParticipant is the direct counterpart of a SHIFT market actor. |
| Node | skos:relatedMatch | [[CIM ConnectivityNode]] | CIM models electrical topology precisely (ConnectivityNode/TopologicalNode); shift:Node is a coarser market-location abstraction that SHOULD reference CIM topology in grid-integrated deployments. |
| [[Asset]] | skos:relatedMatch | [[CIM PowerSystemResource]] | PSR covers grid-side resources in depth; shift:Asset covers consumer-side breadth. Overlap without subsumption. |
| GenerationAsset | skos:relatedMatch | [[CIM GeneratingUnit]] | CIM GeneratingUnit carries full electrical detail SHIFT does not attempt. |
| [[Smart Meter Asset]] | skos:relatedMatch | [[CIM UsagePoint]] | IEC 61968 metering: UsagePoint (plus Meter) is where settlement-grade metering lives in CIM. |
| [[Flexibility Trade]] | skos:relatedMatch | [[CIM EnergyTransaction]] | CIM's transaction model is wholesale-oriented; SHIFT's trade model adds P2P/community semantics CIM lacks. |
| [[Tariff Plan]] | skos:relatedMatch | [[CIM Tariff]] | IEC 61968 Customers Tariff overlaps SHIFT TariffPlan; SHIFT adds dynamic/cap/conflict attributes used by RR-15/20/23/31. |

Mappings are SKOS, deliberately not owl:equivalentClass — equivalence would import external semantics wholesale and collapse the complement claim into a merge.

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]