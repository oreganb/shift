---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS ForecastingActivity
---

# SEAS ForecastingActivity

> https://w3id.org/seas/ForecastingActivity

Activity that forecasts something.

## Aligned SHIFT Concepts
- [[Forecast Data]] — skos:relatedMatch

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]