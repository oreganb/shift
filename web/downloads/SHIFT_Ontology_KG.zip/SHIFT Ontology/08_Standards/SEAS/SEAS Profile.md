---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS Profile
---

# SEAS Profile

> https://w3id.org/seas/Profile

Characteristics of a system in several measurable aspects with a specific temporal context.

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]