---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS Activity
---

# SEAS Activity

> https://w3id.org/seas/Activity

A continuous task or process that an entity can be performing.

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]