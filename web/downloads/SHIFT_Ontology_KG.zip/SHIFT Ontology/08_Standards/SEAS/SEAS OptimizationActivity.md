---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS OptimizationActivity
---

# SEAS OptimizationActivity

> https://w3id.org/seas/OptimizationActivity

Activity that optimizes something.

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]