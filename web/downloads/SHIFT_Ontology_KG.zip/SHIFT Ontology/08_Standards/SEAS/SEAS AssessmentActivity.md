---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS AssessmentActivity
---

# SEAS AssessmentActivity

> https://w3id.org/seas/AssessmentActivity

Activity that assesses something.

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]