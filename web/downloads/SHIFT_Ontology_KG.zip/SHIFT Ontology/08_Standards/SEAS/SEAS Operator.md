---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS Operator
---

# SEAS Operator

> https://w3id.org/seas/Operator

An actor that regulates operations of players in the system.

## Aligned SHIFT Concepts
- [[DSO]] — skos:broadMatch
- [[TSO]] — skos:broadMatch
- [[Market Operator]] — skos:broadMatch
- RegulatoryAuthority — skos:broadMatch

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]