---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS ControlActivity
---

# SEAS ControlActivity

> https://w3id.org/seas/ControlActivity

Activity that in general controls something.

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]