---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS PlanningActivity
---

# SEAS PlanningActivity

> https://w3id.org/seas/PlanningActivity

Activity that creates plans.

## Aligned SHIFT Concepts
- [[Flexibility Schedule]] — skos:relatedMatch

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]