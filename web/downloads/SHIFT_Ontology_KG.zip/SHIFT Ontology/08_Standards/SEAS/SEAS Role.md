---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS Role
---

# SEAS Role

> https://w3id.org/seas/Role

Abstract role of an endurant in some system/domain context.

## Aligned SHIFT Concepts
- [[Actor]] — skos:relatedMatch

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]