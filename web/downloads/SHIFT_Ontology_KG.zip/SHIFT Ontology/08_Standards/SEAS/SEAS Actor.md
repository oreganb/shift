---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - seas
aliases:
  - SEAS Actor
---

# SEAS Actor

> https://w3id.org/seas/Actor

An Actor is an entity that can perform actions.

## Aligned SHIFT Concepts
- [[Actor]] — skos:closeMatch

## Navigation
- [[SEAS]]
- [[SHIFT Ontology]]