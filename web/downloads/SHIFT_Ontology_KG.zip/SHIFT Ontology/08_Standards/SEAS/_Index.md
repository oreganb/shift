# SEAS

## Included Concepts
- [[SEAS Activity]]
- [[SEAS Actor]]
- [[SEAS AssessmentActivity]]
- [[SEAS ControlActivity]]
- [[SEAS ForecastingActivity]]
- [[SEAS Operator]]
- [[SEAS OptimizationActivity]]
- [[SEAS PlanningActivity]]
- [[SEAS Profile]]
- [[SEAS Role]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]