---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Node
---

# OADR Node

> https://w3id.org/def/openadr#Node

Element that interacts with resources in the environment

## Attributes
- `hasNodeName`
- `hasProfileName`
- `hasRegistrationNumber`
- `hasTransportName`

## Aligned SHIFT Concepts
- Node — skos:relatedMatch

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]