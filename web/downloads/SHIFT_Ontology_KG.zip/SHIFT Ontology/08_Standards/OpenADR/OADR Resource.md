---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Resource
---

# OADR Resource

> https://w3id.org/def/openadr#Resource

Entity that is enrolled in the DR Programs and is capable of delivering some sort of change to their load profile in response to receiving a DR signal from a VTN.

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]