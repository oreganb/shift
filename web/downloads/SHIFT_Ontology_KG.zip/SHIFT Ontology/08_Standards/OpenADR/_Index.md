# OpenADR

## Included Concepts
- [[OADR Event]]
- [[OADR EventDescriptor]]
- [[OADR Group]]
- [[OADR Interval]]
- [[OADR Node]]
- [[OADR Opt]]
- [[OADR OptIn]]
- [[OADR OptOut]]
- [[OADR Report]]
- [[OADR Resource]]
- [[OADR Schedule]]
- [[OADR Signal]]
- [[OADR VEN]]
- [[OADR VTN]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]