---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR VTN
---

# OADR VTN

> https://w3id.org/def/openadr#VTN

This is the OpenADR Virtual Top Node that is used to interact with the Resources enrolled in the DR Programs.

## Aligned SHIFT Concepts
- [[Aggregator]] — skos:relatedMatch

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]