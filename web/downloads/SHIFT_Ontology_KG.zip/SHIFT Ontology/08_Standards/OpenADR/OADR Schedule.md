---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Schedule
---

# OADR Schedule

> https://w3id.org/def/openadr#Schedule

Schedule of a target

## Aligned SHIFT Concepts
- [[Flexibility Schedule]] — skos:relatedMatch

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]