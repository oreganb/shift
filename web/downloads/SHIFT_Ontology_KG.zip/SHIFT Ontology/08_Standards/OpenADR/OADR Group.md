---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Group
---

# OADR Group

> https://w3id.org/def/openadr#Group

OpenADR ontology class Group.

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]