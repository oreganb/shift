---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Event
---

# OADR Event

> https://w3id.org/def/openadr#Event

An event is a notification from the utility to demand side resources requesting load shed starting at a specific time, over a specified duration, and may include targeting information designating specific resources that should participate in the event

## Attributes
- `hasEventName`

## Aligned SHIFT Concepts
- [[Demand Response]] — skos:relatedMatch

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]