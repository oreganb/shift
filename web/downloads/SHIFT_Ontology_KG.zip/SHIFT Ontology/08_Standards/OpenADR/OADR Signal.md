---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Signal
---

# OADR Signal

> https://w3id.org/def/openadr#Signal

The actionable information contained in an event such as electricity pricing or specific levels of load shed requested that typically trigger some preprogrammed load shed behavior by the recipient of the event.

## Signal taxonomy (32 subclasses)
- oadr:BidEnergySetpointSignal
- oadr:BidEnergySignal
- oadr:BidLoadSetpointSignal
- oadr:BidLoadSignal
- oadr:BidPriceAbsoluteSignal
- oadr:ChargeStateDeltaSignal
- oadr:ChargeStateMultiplierSignal
- oadr:ChargeStateSetpointSignal
- oadr:ChargeStateSignal
- oadr:DemandChargePriceAbsoluteSignal
- oadr:DemandChargePriceMultiplierSignal
- oadr:DemandChargePriceRelativeSignal
- oadr:DemandChargeSignal
- oadr:ElectricityPriceAbsoluteSignal
- oadr:ElectricityPriceMultiplierSignal
- oadr:ElectricityPriceRelativeSignal
- oadr:ElectricityPriceSignal
- oadr:EnergyPriceAbsolutePriceSignal
- oadr:EnergyPriceMultiplierSignal
- oadr:EnergyPriceRelativeSignal
- oadr:EnergyPriceSignal
- oadr:LoadControlCapacitySignal
- oadr:LoadControlLevelOffsetSignal
- oadr:LoadControlSetpointSignal
- oadr:LoadControlSignal
- oadr:LoadDispatchDeltaSignal
- oadr:LoadDispatchLevelSignal
- oadr:LoadDispatchSetpointSignal
- oadr:LoadDispatchSignal
- oadr:SignalInterval
- oadr:SignalType
- oadr:SimpleSignal
## Attributes
- `hasSignalName`

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]