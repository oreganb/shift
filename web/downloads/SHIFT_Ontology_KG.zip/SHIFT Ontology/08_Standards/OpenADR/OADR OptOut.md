---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR OptOut
---

# OADR OptOut

> https://w3id.org/def/openadr#OptOut

OpenADR ontology class OptOut.

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]