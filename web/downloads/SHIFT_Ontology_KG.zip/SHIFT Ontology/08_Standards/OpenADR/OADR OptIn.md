---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR OptIn
---

# OADR OptIn

> https://w3id.org/def/openadr#OptIn

OpenADR ontology class OptIn.

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]