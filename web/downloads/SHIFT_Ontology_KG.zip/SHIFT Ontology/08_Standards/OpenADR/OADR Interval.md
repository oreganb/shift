---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Interval
---

# OADR Interval

> http://www.w3.org/2006/time#Interval

A temporal entity with non-zero extent or duration, for which the value of the beginning and end are different

## Aligned SHIFT Concepts
- [[Trade Window]] — skos:relatedMatch

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]