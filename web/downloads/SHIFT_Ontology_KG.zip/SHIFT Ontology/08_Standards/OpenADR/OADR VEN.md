---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR VEN
---

# OADR VEN

> https://w3id.org/def/openadr#VEN

This is the OpenADR Virtual End Node that is used to interact with the VTN

## Aligned SHIFT Concepts
- [[Actor]] — skos:relatedMatch

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]