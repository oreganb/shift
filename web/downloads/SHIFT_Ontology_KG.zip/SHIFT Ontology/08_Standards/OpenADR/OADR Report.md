---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Report
---

# OADR Report

> https://w3id.org/def/openadr#Report

Report sent from a VEN to a VTN to report the energy consumption or the status of Resources connected to the VEN

## Attributes
- `hasReportName`

## Aligned SHIFT Concepts
- [[Forecast Data]] — skos:relatedMatch

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]