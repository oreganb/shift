---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR Opt
---

# OADR Opt

> https://w3id.org/def/openadr#Opt

The expected response from the demand side resource owner upon receipt of an event.

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]