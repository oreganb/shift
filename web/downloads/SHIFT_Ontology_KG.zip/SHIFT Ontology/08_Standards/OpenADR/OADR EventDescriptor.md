---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - oadr
aliases:
  - OADR EventDescriptor
---

# OADR EventDescriptor

> https://w3id.org/def/openadr#EventDescriptor

Part of the OpenADR event object that describes metadata about the event, such as program name and event priority

## Attributes
- `hasModificationDateTime`
- `hasModificationNumber`
- `hasModificationReason`
- `hasPriority`
- `hasRandomization`
- `isResponseRequired`
- `isTestEvent`

## Navigation
- [[OpenADR]]
- [[SHIFT Ontology]]