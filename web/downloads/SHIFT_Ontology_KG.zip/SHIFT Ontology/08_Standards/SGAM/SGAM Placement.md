---
type: reference_architecture
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - sgam
aliases:
  - SGAM Placement
---

# SGAM Placement

> https://syc-se.iec.ch/deliveries/sgam-basics/

SGAM (IEC SyC Smart Energy) is a reference architecture, not an ontology — nothing to term-align. Instead, SHIFT constructs are placed in the SGAM cube; this is the demonstration that SHIFT complements the architecture.

Domains: Bulk Generation · Transmission · Distribution · DER · Customer Premises
Zones: Process · Field · Station · Operation · Enterprise · Market
Layers: Component · Communication · Information · Function · Business

| SHIFT construct | Domain(s) | Zone(s) | Layer | note |
|---|---|---|---|---|
| SHIFT Ontology (as a whole) | DER + Customer Premises | Operation / Enterprise / Market | Information | SHIFT is an information-layer artefact: it standardises the data exchanged between functions, it is not itself a component or protocol. |
| FlexibilityTrade / TradeWindow / PeerFlexClearingMechanism | DER + Customer Premises | Market | Function + Business | Market-zone constructs realising business processes. |
| FlexibilityContract / TariffPlan | Customer Premises + DER | Enterprise / Market | Business | Commercial arrangements. |
| Node | Distribution + DER | Station / Operation | Component (referenced) | SHIFT references grid locations; CIM owns their electrical detail. |
| SensorAsset / SmartMeterAsset / ControlAsset | Customer Premises + DER | Process / Field | Component | Field-level devices; SAREF owns their device semantics. |
| FLEXUS Platform | DER + Customer Premises | Operation / Market | Function | The executing system; SHIFT is its information model. |

**For the paper:** SHIFT is an Information-layer artefact for the DER and Customer Premises domains across the Operation, Enterprise and Market zones; SAREF supplies Component-layer device semantics, CIM grid topology, OpenADR Communication-layer signalling, SEAS actor/activity abstractions.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]