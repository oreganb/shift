# SGAM

## Included Concepts
- [[SGAM Placement]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]