---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - standard
aliases:
  - OpenADR
---

# OpenADR

## Overview
OpenADR 2.0b is a DR signalling standard, not an ontology — but a third-party OWL formalisation exists (w3id.org/def/openadr, UPM/albaizq, CC BY 4.0): 77 classes including a 30+ signal taxonomy, VEN/VTN endpoints and report types. Parsed and bundled in the OpenADR folder. An OpenADR Event is the wire-level request; a SHIFT [[Demand Response]] service is the contracted capability answering it. The paper should cite this formalisation rather than dismissing OpenADR outright.

## SHIFT Alignment (SKOS — complement, not replacement)

| SHIFT | relation | external | rationale |
|---|---|---|---|
| [[Demand Response]] | skos:relatedMatch | [[OADR Event]] | An OpenADR Event requests load shed; a SHIFT DemandResponseService is the contracted capability that answers it. Request vs capability. |
| [[Aggregator]] | skos:relatedMatch | [[OADR VTN]] | A VTN is the protocol top node an aggregator or utility operates; it is an endpoint, not the market actor itself. |
| [[Actor]] | skos:relatedMatch | [[OADR VEN]] | A VEN is the protocol endpoint a participating actor operates. |
| [[Flexibility Schedule]] | skos:relatedMatch | [[OADR Schedule]] | Both are time plans; OpenADR's is signal-delivery oriented. |
| [[Trade Window]] | skos:relatedMatch | [[OADR Interval]] | OpenADR Interval is the signal-timing primitive; TradeWindow is the market-clearing primitive. |
| [[Forecast Data]] | skos:relatedMatch | [[OADR Report]] | OpenADR Report carries telemetry/usage from VEN to VTN; ForecastData is forward-looking. Related through the reporting pipeline. |
| Node | skos:relatedMatch | [[OADR Node]] | Name coincidence with partial overlap; OpenADR's Node is a geospatial/topology element in its report model. |

Mappings are SKOS, deliberately not owl:equivalentClass — equivalence would import external semantics wholesale and collapse the complement claim into a merge.

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]