---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - standard
aliases:
  - SEAS
---

# SEAS

## Overview
ITEA Smart Energy Aware Systems ontology suite; the ActorOntology module (v0.10) reifies actors, roles and activities. CC BY 4.0 / Apache 2.0; source Turtle bundled in the SEAS folder. SHIFT flattens SEAS's reified roles into the marketRole attribute for query cheapness. Class detail: [[SEAS Actor]] and siblings.

## SHIFT Alignment (SKOS — complement, not replacement)

| SHIFT | relation | external | rationale |
|---|---|---|---|
| [[Actor]] | skos:closeMatch | [[SEAS Actor]] | Both: an entity that can perform actions in the energy system. |
| [[DSO]] | skos:broadMatch | [[SEAS Operator]] | seas:Operator (regulates operations of players) is broader than the specific DSO role. |
| [[TSO]] | skos:broadMatch | [[SEAS Operator]] | As for DSO: seas:Operator generalises. |
| [[Market Operator]] | skos:broadMatch | [[SEAS Operator]] | As for DSO: seas:Operator generalises. |
| RegulatoryAuthority | skos:broadMatch | [[SEAS Operator]] | As for DSO: seas:Operator generalises. |
| [[Forecast Data]] | skos:relatedMatch | [[SEAS ForecastingActivity]] | SHIFT models the forecast as a data product; SEAS models forecasting as an activity. Data vs process view of the same concern. |
| [[Flexibility Schedule]] | skos:relatedMatch | [[SEAS PlanningActivity]] | Same data-vs-activity duality as ForecastData. |
| [[Actor]] | skos:relatedMatch | [[SEAS Role]] | SHIFT encodes role as a literal (marketRole DP); SEAS reifies Role as a class an entity can hold per context. SEAS's pattern is richer for multi-role actors; SHIFT's is cheaper to query. |

Mappings are SKOS, deliberately not owl:equivalentClass — equivalence would import external semantics wholesale and collapse the complement claim into a merge.

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]