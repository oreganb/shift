---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - standard
aliases:
  - SAREF
---

# SAREF

## Overview
ETSI Smart Applications REFerence ontology, Core v4.1.1 (2024-10-31, ETSI TS 103 264). Device semantics in depth: devices, functions, commands, services (network sense), observations, profiles, commodities. Licence: ETSI Software Licence — not bundled here; fetch from saref.etsi.org. SHIFT sits above SAREF at the market layer. Class detail: [[SAREF Device]] and siblings in the SAREF folder.

## SHIFT Alignment (SKOS — complement, not replacement)

| SHIFT | relation | external | rationale |
|---|---|---|---|
| [[Asset]] | skos:relatedMatch | [[SAREF Device]] | saref:Device is a tangible object; shift:Asset also covers virtual and building assets. Overlapping, neither subsumes the other. |
| [[Sensor Asset]] | skos:closeMatch | [[SAREF Sensor]] | Both: a device designed to observe/measure properties of features of interest. |
| [[Smart Meter Asset]] | skos:closeMatch | [[SAREF Meter]] | Both: an observing device that computes/displays properties; SHIFT adds settlement and revenue-grade attributes SAREF leaves to extensions. |
| [[Control Asset]] | skos:closeMatch | [[SAREF Actuator]] | Both control properties/states of features of interest; SHIFT adds response time, autonomy and cyber-security attributes. |
| [[Flexibility Service]] | skos:relatedMatch | [[SAREF Service]] | FALSE FRIEND. saref:Service is a device function exposed to a network; shift:FlexibilityService is a grid/market service. The name collision is exactly why alignment must be explicit. |
| BehindTheMeterFlexService | skos:relatedMatch | [[SAREF Profile]] | saref:Profile prices a device's commodity use in context; SAREF4ENER specialises it to FlexibilityProfile. SHIFT models the delivered service, SAREF the device-side option space. Complementary. |
| [[Sensor Asset]] | skos:relatedMatch | [[SAREF Observation]] | SHIFT stores last-capture attributes on the sensor; SAREF reifies each act of observation. SAREF is the better home for time-series semantics. |

Mappings are SKOS, deliberately not owl:equivalentClass — equivalence would import external semantics wholesale and collapse the complement claim into a merge.

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]