# Energy

## Included Concepts
- [[OpenADR]]
- [[SAREF]]
- [[SEAS]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]