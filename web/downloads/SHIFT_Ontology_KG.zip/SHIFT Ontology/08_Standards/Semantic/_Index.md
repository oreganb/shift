# Semantic

## Included Concepts
- [[Brick Schema]]
- [[JSON-LD]]
- [[OWL2]]
- [[RDF]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]