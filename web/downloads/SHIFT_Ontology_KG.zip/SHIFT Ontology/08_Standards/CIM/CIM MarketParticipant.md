---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM MarketParticipant
---

# CIM MarketParticipant

> IEC 62325 — IRI UNVERIFIED, check ontology.tno.nl

A party engaging in market activity; carries market roles.

## Aligned SHIFT Concepts
- [[Actor]] — skos:closeMatch

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]