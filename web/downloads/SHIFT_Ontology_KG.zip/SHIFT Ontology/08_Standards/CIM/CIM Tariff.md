---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM Tariff
---

# CIM Tariff

> IEC 61968 — IRI UNVERIFIED, check ontology.tno.nl

A published charging structure for supply to customers.

## Aligned SHIFT Concepts
- [[Tariff Plan]] — skos:relatedMatch

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]