---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM ConnectivityNode
---

# CIM ConnectivityNode

> IEC 61970 — IRI UNVERIFIED, check ontology.tno.nl

A point where conducting equipment connects with zero impedance.

## Aligned SHIFT Concepts
- Node — skos:relatedMatch

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]