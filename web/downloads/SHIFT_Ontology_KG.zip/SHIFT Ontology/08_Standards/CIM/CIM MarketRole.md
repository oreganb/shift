---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM MarketRole
---

# CIM MarketRole

> IEC 62325 — IRI UNVERIFIED, check ontology.tno.nl

A reified role a MarketParticipant holds (e.g. balance responsible party).

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]