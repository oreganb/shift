---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM GeneratingUnit
---

# CIM GeneratingUnit

> IEC 61970 — IRI UNVERIFIED, check ontology.tno.nl

A single or set of synchronous machines converting energy to electricity.

## Aligned SHIFT Concepts
- GenerationAsset — skos:relatedMatch

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]