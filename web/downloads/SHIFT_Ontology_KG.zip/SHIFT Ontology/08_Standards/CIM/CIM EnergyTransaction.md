---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM EnergyTransaction
---

# CIM EnergyTransaction

> IEC 62325 — IRI UNVERIFIED, check ontology.tno.nl

A scheduled exchange of energy between parties.

## Aligned SHIFT Concepts
- [[Flexibility Trade]] — skos:relatedMatch

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]