---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM Meter
---

# CIM Meter

> IEC 61968 — IRI UNVERIFIED, check ontology.tno.nl

Physical asset performing the metering role at a usage point.

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]