---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM PowerSystemResource
---

# CIM PowerSystemResource

> IEC 61970 — IRI UNVERIFIED, check ontology.tno.nl

Root of grid resources: equipment, containers, subsystems.

## Aligned SHIFT Concepts
- [[Asset]] — skos:relatedMatch

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]