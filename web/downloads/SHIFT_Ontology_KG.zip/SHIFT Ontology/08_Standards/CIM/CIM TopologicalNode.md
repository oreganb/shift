---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM TopologicalNode
---

# CIM TopologicalNode

> IEC 61970 — IRI UNVERIFIED, check ontology.tno.nl

A set of connectivity nodes connected through closed switches.

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]