---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - cim
aliases:
  - CIM UsagePoint
---

# CIM UsagePoint

> IEC 61968 — IRI UNVERIFIED, check ontology.tno.nl

Logical metering/service point for a premises; anchor of settlement metering.

## Aligned SHIFT Concepts
- [[Smart Meter Asset]] — skos:relatedMatch

## Navigation
- [[CIM]]
- [[SHIFT Ontology]]