# CIM

## Included Concepts
- [[CIM ConnectivityNode]]
- [[CIM EnergyTransaction]]
- [[CIM GeneratingUnit]]
- [[CIM MarketParticipant]]
- [[CIM MarketRole]]
- [[CIM Meter]]
- [[CIM PowerSystemResource]]
- [[CIM Tariff]]
- [[CIM TopologicalNode]]
- [[CIM UsagePoint]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]