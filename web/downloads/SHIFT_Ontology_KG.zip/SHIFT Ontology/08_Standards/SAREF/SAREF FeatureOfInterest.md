---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF FeatureOfInterest
---

# SAREF FeatureOfInterest

> https://saref.etsi.org/core/FeatureOfInterest

Any real-world entity from which a property or state may be acted upon.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]