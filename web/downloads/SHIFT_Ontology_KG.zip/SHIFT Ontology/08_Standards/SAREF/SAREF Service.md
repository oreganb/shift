---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Service
---

# SAREF Service

> https://saref.etsi.org/core/Service

A digital representation of a function in a network, making it discoverable, registerable and remotely controllable.

## Aligned SHIFT Concepts
- [[Flexibility Service]] — skos:relatedMatch

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]