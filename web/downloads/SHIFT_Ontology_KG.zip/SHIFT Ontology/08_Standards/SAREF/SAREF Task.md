---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Task
---

# SAREF Task

> https://saref.etsi.org/core/Task

Goals for which a device is designed, from a user perspective.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]