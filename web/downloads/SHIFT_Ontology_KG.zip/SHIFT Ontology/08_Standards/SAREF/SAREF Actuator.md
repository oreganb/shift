---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Actuator
---

# SAREF Actuator

> https://saref.etsi.org/core/Actuator

A device designed to control one or more properties or states of one or more features of interest.

## Aligned SHIFT Concepts
- [[Control Asset]] — skos:closeMatch

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]