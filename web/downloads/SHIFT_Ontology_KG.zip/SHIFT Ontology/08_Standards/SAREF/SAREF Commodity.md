---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Commodity
---

# SAREF Commodity

> https://saref.etsi.org/core/Commodity

A marketable item which may be supplied without qualitative differentiation.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]