---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Device
---

# SAREF Device

> https://saref.etsi.org/core/Device

A tangible object designed to accomplish a particular task by performing one or more functions.

## Aligned SHIFT Concepts
- [[Asset]] — skos:relatedMatch

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]