---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF PropertyValue
---

# SAREF PropertyValue

> https://saref.etsi.org/core/PropertyValue

The value for a property, with optional literal value and unit of measure.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]