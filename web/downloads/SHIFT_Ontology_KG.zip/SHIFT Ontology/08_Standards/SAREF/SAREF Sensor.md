---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Sensor
---

# SAREF Sensor

> https://saref.etsi.org/core/Sensor

A device designed to observe and measure one or more properties or states of one or more features of interest.

## Aligned SHIFT Concepts
- [[Sensor Asset]] — skos:closeMatch

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]