---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Observation
---

# SAREF Observation

> https://saref.etsi.org/core/Observation

The act of estimating or calculating a value of a property or state of a feature of interest.

## Aligned SHIFT Concepts
- [[Sensor Asset]] — skos:relatedMatch

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]