---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Profile
---

# SAREF Profile

> https://saref.etsi.org/core/Profile

Describes the money earned or paid for the use (production or consumption) of a commodity by a device in a certain context. Basis of SAREF4ENER FlexibilityProfile.

## Aligned SHIFT Concepts
- BehindTheMeterFlexService — skos:relatedMatch

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]