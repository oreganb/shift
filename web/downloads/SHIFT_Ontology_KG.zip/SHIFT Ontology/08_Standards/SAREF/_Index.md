# SAREF

## Included Concepts
- [[SAREF Actuation]]
- [[SAREF Actuator]]
- [[SAREF Appliance]]
- [[SAREF Command]]
- [[SAREF Commodity]]
- [[SAREF Device]]
- [[SAREF FeatureOfInterest]]
- [[SAREF Function]]
- [[SAREF Meter]]
- [[SAREF Observation]]
- [[SAREF Profile]]
- [[SAREF PropertyValue]]
- [[SAREF Sensor]]
- [[SAREF Service]]
- [[SAREF State]]
- [[SAREF Task]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]