---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Meter
---

# SAREF Meter

> https://saref.etsi.org/core/Meter

A device designed to observe and additionally compute and/or display one or more properties of features of interest.

## Aligned SHIFT Concepts
- [[Smart Meter Asset]] — skos:closeMatch

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]