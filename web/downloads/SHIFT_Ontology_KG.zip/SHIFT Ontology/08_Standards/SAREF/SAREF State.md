---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF State
---

# SAREF State

> https://saref.etsi.org/core/State

Identifiable conditions that features of interest are or may be in.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]