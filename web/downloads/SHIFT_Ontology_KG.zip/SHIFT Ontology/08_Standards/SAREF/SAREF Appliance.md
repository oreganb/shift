---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Appliance
---

# SAREF Appliance

> https://saref.etsi.org/core/Appliance

A device designed to accomplish a particular task for occupant use; consumes, produces or stores some commodity.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]