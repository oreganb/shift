---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Command
---

# SAREF Command

> https://saref.etsi.org/core/Command

The lowest-level directives a function exposes to some network.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]