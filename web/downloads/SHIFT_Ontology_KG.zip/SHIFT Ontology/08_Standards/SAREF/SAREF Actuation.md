---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Actuation
---

# SAREF Actuation

> https://saref.etsi.org/core/Actuation

The act of controlling the state of the world using an actuator.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]