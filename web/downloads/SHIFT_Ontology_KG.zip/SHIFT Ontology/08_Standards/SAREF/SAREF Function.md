---
type: external_class
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
  - external
  - saref
aliases:
  - SAREF Function
---

# SAREF Function

> https://saref.etsi.org/core/Function

Logical groups of commands that devices support to accomplish their tasks.

## Navigation
- [[SAREF]]
- [[SHIFT Ontology]]