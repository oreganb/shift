# Infrastructure

## Included Concepts
- [[Asset]]
- [[Control Asset]]
- [[Sensor Asset]]
- [[Smart Meter Asset]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]