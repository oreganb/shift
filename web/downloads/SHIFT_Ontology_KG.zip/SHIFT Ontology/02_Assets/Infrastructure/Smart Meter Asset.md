---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Smart Meter Asset
---

# Smart Meter Asset

## Overview
A revenue-grade metering point; carries granularity, remote-readability, settlement and tamper attributes.

**OWL identifier:** `shift:SmartMeterAsset`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `accuracyClass` | `string` |
| `dataExportFormat` | `string` |
| `firmwareVersion` | `string` |
| `granularity_sec` | `integer` |
| `isBiDirectional` | `boolean` |
| `isRemoteReadable` | `boolean` |
| `isRevenueGrade` | `boolean` |
| `isTamperDetected` | `boolean` |
| `isUsedForSettlement` | `boolean` |
| `lastMaintenanceDate` | `dateTime` |
| `lastReadTime` | `dateTime` |
| `meterType` | `string` |
| `smartMeterID` | `string` |
| `validatedByRegulator` | `boolean` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `controlledBy` | [[Control Asset]] |
| `feedsIntoPlatform` | [[Transactive Platform]] |
| `monitorsActor` | [[Actor]] |
| `monitorsAsset` | [[Asset]] |
| `ownedBy` | [[Actor]] |
| `usedForValidation` | [[Flexibility Schedule]] |
| `usedInForecast` | [[Forecast Data]] |
| Node `hasSmartMeter` | this |
| [[Market Bidding]] `measuredBy` | this |
| [[Asset]] `monitoredBy` | this |
| [[Transactive Platform]] `receivesDataFromMeter` | this |
| [[Forecast Data]] `validatedAgainstData` | this |
| [[Flexibility Contract]] `validatedBy` | this |
| [[Demand Response]] `verifiedBy` | this |

## Reasoning Rules
SHIFT-RR-03 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:closeMatch | [[SAREF Meter]] | Both: an observing device that computes/displays properties; SHIFT adds settlement and revenue-grade attributes SAREF leaves to extensions. |
| skos:relatedMatch | [[CIM UsagePoint]] | IEC 61968 metering: UsagePoint (plus Meter) is where settlement-grade metering lives in CIM. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]