---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Control Asset
---

# Control Asset

## Overview
A controller capable of executing setpoints or commands against other assets; carries response time, autonomy, security and edge-deployment attributes.

**OWL identifier:** `shift:ControlAsset`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `allowsManualOverride` | `boolean` |
| `controlAccuracy_percent` | `decimal` |
| `controlAssetID` | `string` |
| `controlAssetType` | `string` |
| `controlStrategy` | `string` |
| `firmwareVersion` | `string` |
| `isAutonomous` | `boolean` |
| `isCyberSecure` | `boolean` |
| `isEdgeDeployed` | `boolean` |
| `isInteroperable` | `boolean` |
| `lastUpdateTime` | `dateTime` |
| `responseTime_ms` | `integer` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `activatesService` | [[Flexibility Service]] |
| `assignedToWindow` | [[Trade Window]] |
| `connectedToSensor` | [[Sensor Asset]] |
| `controlsAsset` | [[Asset]] |
| `informedByForecast` | [[Forecast Data]] |
| `managedByActor` | [[Actor]] |
| `reportsToPlatform` | [[Transactive Platform]] |
| `updatesSchedule` | [[Flexibility Schedule]] |
| [[Sensor Asset]] `connectedToControl` | this |
| [[Asset]] `controlledBy` | this |
| [[Trade Window]] `controlsAssetOperation` | this |
| [[Transactive Platform]] `controlsViaAsset` | this |
| [[Forecast Data]] `generatedBySystem` | this |
| [[Flexibility Schedule]] `updatedBy` | this |

## Reasoning Rules
SHIFT-RR-03, SHIFT-RR-10 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:closeMatch | [[SAREF Actuator]] | Both control properties/states of features of interest; SHIFT adds response time, autonomy and cyber-security attributes. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]