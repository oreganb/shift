---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Sensor Asset
---

# Sensor Asset

## Overview
A measurement device producing observations; carries accuracy, frequency, calibration and fault attributes.

**OWL identifier:** `shift:SensorAsset`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `accuracyRating_percent` | `decimal` |
| `dataFrequency_sec` | `integer` |
| `firmwareVersion` | `string` |
| `installationDate` | `dateTime` |
| `isBatteryPowered` | `boolean` |
| `isFaultDetected` | `boolean` |
| `isIndoorSensor` | `boolean` |
| `isUsedForValidation` | `boolean` |
| `isWireless` | `boolean` |
| `lastCalibrationDate` | `dateTime` |
| `lastDataCaptureTime` | `dateTime` |
| `sensorID` | `string` |
| `sensorType` | `string` |
| `unitOfMeasurement` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `attachedToNode` | Node |
| `connectedToControl` | [[Control Asset]] |
| `monitorsAsset` | [[Asset]] |
| `ownedBy` | [[Actor]] |
| `usedInFlexService` | [[Flexibility Service]] |
| `usedInForecast` | [[Forecast Data]] |
| [[Control Asset]] `connectedToSensor` | this |
| [[Asset]] `monitoredBy` | this |
| Node `monitoredBySensor` | this |
| [[Demand Response]] `verifiedBy` | this |

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:closeMatch | [[SAREF Sensor]] | Both: a device designed to observe/measure properties of features of interest. |
| skos:relatedMatch | [[SAREF Observation]] | SHIFT stores last-capture attributes on the sensor; SAREF reifies each act of observation. SAREF is the better home for time-series semantics. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]