---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Asset
---

# Asset

## Overview
Any physical or virtual resource that can consume, generate, store, sense, meter or control energy.

**OWL identifier:** `shift:Asset`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `assetID` | `string` |
| `operatingStatus` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `assignedToVPPO` | VirtualPowerPlantOperator |
| `connectedTo` | [[Asset]] |
| `connectedToBuilding` | BuildingAsset |
| `controlledBy` | [[Control Asset]] |
| `linkedToForecast` | [[Forecast Data]] |
| `locatedAt` | Node |
| `monitoredBy` | [[Sensor Asset]] |
| `participatesInFlexibility` | [[Flexibility Service]] |
| `usedInFlexibilityService` | [[Flexibility Service]] |
| [[Flexibility Schedule]] `associatedWithAsset` | this |
| [[Asset]] `connectedTo` | this |
| VirtualPowerPlantOperator `controls` | this |
| [[Control Asset]] `controlsAsset` | this |
| [[Demand Response]] `deliveredBy` | this |
| Node `hostsAsset` | this |
| BehindTheMeterFlexService `linkedToAsset` | this |
| [[Sensor Asset]] `monitorsAsset` | this |
| [[Forecast Data]] `relatedToAsset` | this |

## Reasoning Rules
SHIFT-RR-13, SHIFT-RR-18, SHIFT-RR-28 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[SAREF Device]] | saref:Device is a tangible object; shift:Asset also covers virtual and building assets. Overlapping, neither subsumes the other. |
| skos:relatedMatch | [[CIM PowerSystemResource]] | PSR covers grid-side resources in depth; shift:Asset covers consumer-side breadth. Overlap without subsumption. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]