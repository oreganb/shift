# DERs

## Included Concepts
- [[Battery]]
- [[EV]]
- [[Heat Pump]]
- [[Inverter]]
- [[PV Panel]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]