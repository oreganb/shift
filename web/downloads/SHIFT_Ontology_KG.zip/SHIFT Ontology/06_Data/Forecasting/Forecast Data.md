---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Forecast Data
---

# Forecast Data

## Overview
A forecast product (load, generation, availability) with granularity, accuracy and provenance.

**OWL identifier:** `shift:ForecastData`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `confidenceInterval_percent` | `decimal` |
| `dataFileURL` | `anyURI` |
| `endTime` | `dateTime` |
| `forecastAccuracy_percent` | `decimal` |
| `forecastDataHash` | `string` |
| `forecastID` | `string` |
| `forecastType` | `string` |
| `isProbabilistic` | `boolean` |
| `isUsedInDecisionMaking` | `boolean` |
| `lastUpdatedAt` | `dateTime` |
| `startTime` | `dateTime` |
| `timeGranularity_min` | `integer` |
| `units` | `string` |

## Semantic Relationships

| Relationship | Target |
|---|---|
| `generatedBySystem` | [[Control Asset]] |
| `relatedToAsset` | [[Asset]] |
| `usedInSchedule` | [[Flexibility Schedule]] |
| `usedInService` | [[Flexibility Service]] |
| `usedInTradeWindow` | [[Trade Window]] |
| `validatedAgainstData` | [[Smart Meter Asset]] |
| [[Control Asset]] `informedByForecast` | this |
| [[Asset]] `linkedToForecast` | this |
| [[Tariff Plan]] `referencedInForecast` | this |
| [[Sensor Asset]] `usedInForecast` | this |

## Reasoning Rules
SHIFT-RR-05 — see [[Reasoning Rules]]

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[SEAS ForecastingActivity]] | SHIFT models the forecast as a data product; SEAS models forecasting as an activity. Data vs process view of the same concern. |
| skos:relatedMatch | [[OADR Report]] | OpenADR Report carries telemetry/usage from VEN to VTN; ForecastData is forward-looking. Related through the reporting pipeline. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]