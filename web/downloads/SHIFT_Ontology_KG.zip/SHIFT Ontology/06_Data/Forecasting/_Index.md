# Forecasting

## Included Concepts
- [[Forecast Data]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]