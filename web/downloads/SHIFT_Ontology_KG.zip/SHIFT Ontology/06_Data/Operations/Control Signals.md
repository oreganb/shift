---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Control Signals
---

# Control Signals

## Overview
Setpoints and commands issued to control assets. SHIFT records the controlling relationship; OpenADR's ontology carries the full signal taxonomy (30+ signal classes).

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Semantic Relationships

| Relationship | Target |
|---|---|
| partOf | [[SHIFT Ontology]] |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]