# Operations

## Included Concepts
- [[Conditions]]
- [[Control Signals]]
- [[Node]]
- [[Performance Log]]
- [[Semantic Validation]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]