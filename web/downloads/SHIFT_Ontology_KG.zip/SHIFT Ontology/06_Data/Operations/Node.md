---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Node
---

# Node

## Overview
A grid location (feeder, substation, island) carrying load, DER capacity and congestion attributes. Rule SHIFT-RR-02 infers congestion points; RR-19 detects overcommitment risk. In grid-integrated deployments a SHIFT Node should reference CIM topology (ConnectivityNode / TopologicalNode) rather than remodel it.

**OWL identifier:** `shift:Node`

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Attributes

| property | range |
|---|---|
| `congestionRiskScore` | `decimal` |
| `isCongestionPoint` | `boolean` |
| `isIslandable` | `boolean` |
| `isPeerTradeEnabled` | `boolean` |
| `lastCongestionEvent` | `dateTime` |
| `latitude` | `decimal` |
| `longitude` | `decimal` |
| `nodeID` | `string` |
| `nodeType` | `string` |
| `totalConnectedLoad_kW` | `float` |
| `totalDERCapacity_kW` | `float` |
| `voltageLevel_kV` | `float` |

## External Alignment

| relation | external | rationale |
|---|---|---|
| skos:relatedMatch | [[CIM ConnectivityNode]] | CIM models electrical topology precisely; SHIFT Node is a coarser market-location abstraction that should reference CIM topology in grid-integrated deployments. |
| skos:relatedMatch | [[OADR Node]] | Name coincidence with partial overlap; OpenADR's Node is a geospatial element in its report model. |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
