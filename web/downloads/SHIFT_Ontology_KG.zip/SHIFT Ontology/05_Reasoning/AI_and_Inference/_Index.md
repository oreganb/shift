# AI and Inference

## Included Concepts
- [[Fairness Rotation]]
- [[Forecast Integration]]
- [[Reasoning Rule]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]