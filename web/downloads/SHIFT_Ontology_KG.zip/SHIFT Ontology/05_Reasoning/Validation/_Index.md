# Validation

## Included Concepts
- [[Capacity Compliance]]
- [[Trade Validation]]
- [[Violation Detection]]

## Connected Domains
- [[SHIFT Ontology]]
- [[Semantic Relationships]]
- [[Ontology Architecture]]