---
type: ontology_node
ontology: SHIFT
status: active
tags:
  - shift
  - ontology
  - semantic-energy
aliases:
  - Violation Detection
---

# Violation Detection

## Overview
Rules that assert violation or failure states: RR-04 expiry, RR-07 offline-asset failure, RR-17 underperformance, RR-22 invalid multi-window trades, RR-28 low-reliability assets.

## Parent Domain
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]

## Semantic Relationships

| Relationship | Target |
|---|---|
| partOf | [[SHIFT Ontology]] |

## Related Standards
- [[OWL2]]
- [[RDF]]
- [[JSON-LD]]
- [[SAREF]]
- [[CIM]]

## Related Methodologies
- [[Ontology Engineering]]
- [[Semantic Interoperability]]
- [[Knowledge Graph Engineering]]
- [[Machine Learning Integration]]

## Used In Platforms
- [[FLEXUS]]
- [[OPTIX]]
- [[O-CEI]]
- [[INNOV8HEAT]]

## AI Context
This node is connected to semantic reasoning, interoperability, AI-ready data structures, forecasting, flexibility orchestration, and transactive energy workflows.

## Navigation
- [[SHIFT Ontology]]
- [[Ontology Architecture]]
- [[Semantic Relationships]]
- [[Flexibility Service]]
- [[Flexibility Trade]]
- [[Forecast Data]]